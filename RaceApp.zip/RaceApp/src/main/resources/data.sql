DROP TABLE IF EXISTS kangaroo_race;

CREATE TABLE kangaroo_race (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  kangaroo_1_start_point int NOT NULL,
  kangaroo_1_speed int NOT NULL,
  kangaroo_2_start_point int NOT NULL,
  kangaroo_2_speed int NOT NULL,
  meeting_point int not null
);