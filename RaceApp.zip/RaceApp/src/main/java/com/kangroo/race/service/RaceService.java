package com.kangroo.race.service;

import com.kangroo.race.dto.KangarooRaceInput;
import com.kangroo.race.model.KangarooRace;
import java.util.List;

public interface RaceService {
  public void calculateMeetPoint(KangarooRaceInput raceInput);

  public List<KangarooRace> getAllResults();
}
