package com.kangroo.race.dto;
import lombok.Data;
import javax.validation.constraints.NotNull;

@Data
public class KangarooRaceInput {

  @NotNull
  private KangarooDetails kangaroo1;
  @NotNull
  private KangarooDetails kangaroo2;

  @Data
  public static class KangarooDetails {

    @NotNull
    private Integer position;
    @NotNull
    private Integer speed;
  }
}
