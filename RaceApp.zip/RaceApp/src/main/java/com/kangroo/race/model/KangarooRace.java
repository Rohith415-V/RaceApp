package com.kangroo.race.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "kangaroo_race")
public class KangarooRace {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Integer id;

  @Column(name = "kangaroo_1_start_point")
  private Integer kangarooOneStartPoint;

  @Column(name = "kangaroo_1_speed")
  private Integer kangarooOneSpeed;

  @Column(name = "kangaroo_2_start_point")
  private Integer kangarooTwoStartPoint;

  @Column(name = "kangaroo_2_speed")
  private Integer kangarooTwoSpeed;

  @Column(name = "meeting_point")
  private Integer meetingPoint;
}
