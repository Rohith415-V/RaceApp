package com.kangroo.race.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;

@Configuration
@EnableWebSecurity
public class SpringSecConfig extends WebSecurityConfigurerAdapter {

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http.csrf().disable().authorizeRequests()
        .antMatchers("/meeting-point").access("hasRole('CIRCUS_CHOREOGRAPH')")
        .antMatchers("/meeting-points").access("hasRole('CIRCUS_ADMIN')")
        .anyRequest().authenticated().and().httpBasic().and()
        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
  }

  @Override
  protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    auth.inMemoryAuthentication()
        .withUser("choreographer").password(("{noop}choreographerpwd")).roles("CIRCUS_CHOREOGRAPH")
        .and()
        .withUser("admin").password("{noop}adminpwd").roles("CIRCUS_ADMIN")
        .and()
        .withUser("viewer").password("{noop}viewerpwd").roles("CIRCUS_VIEWER");
  }

}
