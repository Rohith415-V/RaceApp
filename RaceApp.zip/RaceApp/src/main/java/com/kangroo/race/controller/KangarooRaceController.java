package com.kangroo.race.controller;

import com.kangroo.race.dto.KangarooRaceInput;
import com.kangroo.race.model.KangarooRace;
import com.kangroo.race.service.RaceService;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/kangaroo")
public class KangarooRaceController {

  @Autowired
  private RaceService raceService;

  @PreAuthorize("hasAuthority('CIRCUS_CHOREOGRAPH')")
  @PostMapping("/meeting-point")
  public ResponseEntity<Void> captureMeetingPoint(
      @Valid @RequestBody KangarooRaceInput raceInput,
      BindingResult bindingResult) {
    if (bindingResult.hasErrors()) {
      return ResponseEntity.badRequest().build();
    }
    raceService.calculateMeetPoint(raceInput);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  @PreAuthorize("hasAuthority('CIRCUS_ADMIN')")
  @GetMapping("/meeting-points")
  public ResponseEntity<List<KangarooRace>> getMeetingPoint() {
    return ResponseEntity.ok(raceService.getAllResults());
  }

}
