package com.kangroo.race.repository;

import com.kangroo.race.model.KangarooRace;
import java.util.List;
import org.springframework.data.repository.CrudRepository;

public interface KangarooRaceRepository extends CrudRepository<KangarooRace, Integer> {

  List<KangarooRace> findAll();
}
