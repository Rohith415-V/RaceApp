package com.kangroo.race.service;

import com.kangroo.race.dto.KangarooRaceInput;
import com.kangroo.race.model.KangarooRace;
import com.kangroo.race.repository.KangarooRaceRepository;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class RaceServiceImpl implements RaceService {

  @Autowired
  KangarooRaceRepository raceRepository;

  @Override
  public void calculateMeetPoint(KangarooRaceInput raceInput) {

    Integer k1 = raceInput.getKangaroo1().getPosition();
    Integer v1 = raceInput.getKangaroo1().getSpeed();
    Integer k2 = raceInput.getKangaroo2().getPosition();
    Integer v2 = raceInput.getKangaroo2().getSpeed();

    if((k1 < k2 && v1 <= v2) || (k1 > k2 && v1 >= v2)){
      return;
    }
    KangarooRace race = race = KangarooRace.builder()
        .kangarooOneStartPoint(k1)
        .kangarooOneSpeed(v1)
        .kangarooTwoStartPoint(k2)
        .kangarooTwoSpeed(v2)
        .build();
    if(k1 == k2){
      race.setMeetingPoint(k1);
    } else {
      Integer k1CurrPos = k1;
      Integer k2CurrPos = k2;
      while (k1CurrPos != k2CurrPos) {
        k1CurrPos += v1;
        k2CurrPos += v2;
      }
      race.setMeetingPoint(k1CurrPos);
    }
    raceRepository.save(race);
  }

  @Override
  public List<KangarooRace> getAllResults() {
    return raceRepository.findAll();
  }
}
