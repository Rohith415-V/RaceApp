I am using in memory H2 dataase for this app

I have configured below users with corresponding credentials
username            password            role
---------------------------------------------
choreographer       choreographerpwd    CIRCUS_CHOREOGRAPH
admin               adminpwd            CIRCUS_ADMIN
viewer              viewerpwd           CIRCUS_VIEWER

#run below command to build the jar
mvn -U clean install

#run below command to run the jar
java -jar target/race-0.0.1-SNAPSHOT.jar

#Below POST request shall be used to calculate the meeting for a set of knagaroo details    
POST localhost:8989/race/kangaroo/meeting-point
RequestBody:
{
  "kangaroo1":{
    "position":1,
    "speed":2
  },
  "kangaroo2":{
    "position":2,
    "speed":1
  }
}

#Below GET request shall be used to get the kangaroo set details with corresponding meeting points
GET localhost:8989/race/kangaroo/meeting-points

#run below command to build the jar
mvn -U clean install

#run below command to run the jar
java -jar target/race-0.0.1-SNAPSHOT.jar


